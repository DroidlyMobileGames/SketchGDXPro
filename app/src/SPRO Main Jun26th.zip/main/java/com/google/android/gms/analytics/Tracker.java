package com.google.android.gms.analytics;

import java.util.Map;

public class Tracker {

    public Tracker() {
    }

    public void enableAdvertisingIdCollection(boolean enable) {
    }

    public void enableExceptionReporting(boolean enable) {
    }

    public void send(Map<String, String> map) {
    }

    public void setScreenName(String screenName) {
    }
}
