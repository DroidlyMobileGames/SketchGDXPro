package a.a.a;

public class uq {
    public static final String[] a = {"Intent", "SharedPreferences", "Calendar", "Vibrator", "Timer", "SoundPool", "MediaPlayer", "Dialog", "ObjectAnimator", "Firebase DB", "Interstitial Ad", "Firebase Storage", "Camera", "FilePicker", "RequestNetwork", "TextToSpeech", "SpeechToText", "BluetoothConnect", "ProgressDialog", "RewardedVideoAd", "TimePickerDialog", "Notification"};
    public static final String[] b = {"abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "extends", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null", "package", "private", "protected", "public", "return", "short", "static", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void", "volatile", "while", "Override", "Deprecated", "Activity", "Bundle", "LayoutInfater", "Toolbar", "DrawerLayout", "FloatingActionButton", "View", "Context", "EditText", "onCreate", "onClick", "LinearLayout", "FrameLayout", "RelativeLayout", "TextView", "Spinner", "CheckBox", "WebView", "CalendarView", "ImageView", "Button", "ArrayList", "String", "Intent", "SharedPreferences", "Calendar", "true", "false", "none", "SeekBar", "Switch", "root", "R", "CalendarView", "gyroscope", "FirebaseDatabase", "DatabaseReference", "FirebaseStorage", "StorageReference", "File", "AdView", "RequestNetwork", "MediaController", "NetworkRequest", "RequestNetworkController", "ProgressBar", "TextToSpeech", "SpeechRecognizer", "BluetoothConnect", "BluetoothController", "GoogleMapController", "MapView", "GoogleMap", "LocationListener", "LocationManager", "ProgressDialog", "RewardedVideoAd", "DatePickerDialog", "TimePickerDialog", "Notification", "ListView", "CardView", "GridView", "VideoView", "SearchView", "RadioButton", "RatingBar", "DatePicker", "TimePicker", "DigitalClock", "AnalogClock", "RecyclerView", "ViewPager", "SwipeRefreshLayout", "CoordinatorLayout", "TabLayout", "TextInputLayout", "BottomNavigationView", "ImageButton", "ShimmerButton", "ShimmerTextView", "CircleImageView", "AutoCompleteTextView", "MultiAutoCompleteTextView", "BadgeView", "BubbleLayout", "PatternLockView", "WaveSideBar", "BottomAppBar", "BottomSheetBehavior", "NavigationView", "NestedScrollView", "CollapsingToolbarLayout", "AppBarLayout"};
    public static final String[] c = {"ACTION_DIAL", "ACTION_CALL", "ACTION_VIEW", "ACTION_MAIN", "ACTION_PICK", "ACTION_SEND", "ACTION_SENDTO", "ACTION_SEND_MULTIPLE", "ACTION_SET_WALLPAPER", "ACTION_SEARCH", "ACTION_SCREEN_ON", "ACTION_SCREEN_OFF"};
    public static final String[] d = {"SINGLE_TOP", "CLEAR_TOP"};
    public static final String[] e = {"YEAR", "MONTH", "DAY_OF_MONTH", "HOUR", "MINUTE", "SECOND"};
    public static final String[] f = {"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};
    public static final String[] g = {"VISIBLE", "INVISIBLE", "GONE"};
    public static final String[] h = {"LOAD_DEFAULT", "LOAD_CACHE_ELSE_NETWORK", "LOAD_NO_CACHE", "LOAD_CACHE_ONLY"};
    public static final String[] i = {"rotation", "translationX", "translationY", "alpha", "scaleX", "scaleY"};
    public static final String[] j = {"RESTART", "REVERSE"};
    public static final String[] k = {"Linear", "Accelerate", "Decelerate", "AccelerateDecelerate", "Bounce"};
    public static final String[] l = {"DIRECTORY_MUSIC", "DIRECTORY_PODCASTS", "DIRECTORY_RINGTONES", "DIRECTORY_ALARMS", "DIRECTORY_NOTIFICATIONS", "DIRECTORY_PICTURES", "DIRECTORY_MOVIES", "DIRECTORY_DOWNLOADS", "DIRECTORY_DCIM", "DIRECTORY_DOCUMENT"};
    public static final String[] m = {"onCreate", "setContentView", "initialize", "initializeLogic", "getRandom", "showMessage", "getDip", "getDisplayWidthPixels", "getDisplayHeightPixels"};
    public static final String[] n = {"GET", "POST", "PUT", "DELETE"};
    public static final String[] o = {"REQUEST_PARAM", "REQUEST_BODY"};
    public static final String[] p = {"GPS_PROVIDER", "NETWORK_PROVIDER"};
    public static final String[] q = {"MAP_TYPE_NONE", "MAP_TYPE_NORMAL", "MAP_TYPE_SATELLITE", "MAP_TYPE_TERRAIN", "MAP_TYPE_HYBRID"};
    public static final String[] r = {"HUE_RED", "HUE_ORANGE", "HUE_YELLOW", "HUE_GREEN", "HUE_CYAN", "HUE_AZURE", "HUE_BLUE", "HUE_VIOLET", "HUE_MAGENTA", "HUE_ROSE"};

    public static String[] a() {
        return m;
    }

    public static String[] b() {
        return c;
    }

    public static String[] c() {
        return d;
    }
}
