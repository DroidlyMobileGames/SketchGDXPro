package a.a.a;

import android.content.Context;

//Note: Don't remove this class and it's methods, because it's used in some um-decompiled classes

public class xo {

    public static void a(to idk) {
    }

    public static void a(Context context) {
    }

    public static void i() {
    }

}
